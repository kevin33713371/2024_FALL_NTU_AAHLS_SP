
# ifndef __MMULT_H__
# define __MMULT_H__

extern "C"{
void mmult(volatile float* a, volatile float* b, volatile float* c);
}

#endif
